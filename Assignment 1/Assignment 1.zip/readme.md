CS4802 - Biovisualization
Assignment 1
Jonathan Wu - jtwu
Conway's Game of Life

1.  All code is original and is contained in asgnm1.html
	The script utilizes the paper.js library which was used for graphical display
2.	I used the standard rules from Conway's Game of Life which are:
	- Live cells die if they have less than two live neighbours, or more than three neighbours
	- Dead cells with exactly three live neighbours becomes alive
3.  The first generation is generated randomly
4.	To run the project open the asgnm1.html file with a browser (tested on Chrome)
	asgnm1.html must be contained in the same directory as the "js" folder which contains the paper.js library.